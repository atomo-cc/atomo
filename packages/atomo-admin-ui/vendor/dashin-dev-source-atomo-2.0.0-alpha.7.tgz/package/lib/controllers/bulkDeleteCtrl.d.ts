import { Action } from "@dashin-dev/dashin";
import { AtomoBulkDeleteCtrlProps } from "../types";
export default function bulkDeleteCtrl<RowData extends object = any>({ model, t, tableRef, idField, baseUrl, }: AtomoBulkDeleteCtrlProps): Action<RowData>;
