import { EditableDataType } from "@dashin-dev/dashin";
import { AtomoEditableCtrlProps } from "../types";
export default function editableCtrl<RowData extends object = any>({ model, t, baseUrl, idField, formatError, consistencyDelayMs, }: AtomoEditableCtrlProps): EditableDataType<RowData>;
