import { QueryResult } from "@dashin-dev/dashin";
import { AtomoDataCtrlProps } from "../types";
export default function dataCtrl<RowData extends object>({ model, tableQuery, searchField, t, baseUrl, formatError, }: AtomoDataCtrlProps<RowData>): Promise<QueryResult<RowData>>;
