import { CollectionRegistry, CollectionMeta } from "@dashin-dev/dashin";
import { AtomoSchemaMeta, AtomoModelMeta } from "./types";
export interface BuildRegistryOptions {
    baseUrl?: string;
    t?: (key: string) => string;
    customTitleField?: Record<string, (rec: any) => string>;
    customSubtitleField?: Record<string, (rec: any) => string>;
}
export declare function extractModelRelations(model: AtomoModelMeta): CollectionMeta["relations"];
export declare function buildAtomoRegistry(schema: AtomoSchemaMeta, options?: BuildRegistryOptions): CollectionRegistry;
