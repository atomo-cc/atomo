import { MenuType } from "@dashin-dev/dashin";
import { AtomoSchemaMeta } from "./types";
export declare function getModelEvaIcon(modelName: string): string;
export interface BuildMenuOptions {
    parentGroup?: string;
    parentLabel?: string;
    parentIcon?: string;
    userRole?: string;
    basePathPrefix?: string;
}
export declare function buildAtomoMenuData(schema: AtomoSchemaMeta, options?: BuildMenuOptions): MenuType[];
