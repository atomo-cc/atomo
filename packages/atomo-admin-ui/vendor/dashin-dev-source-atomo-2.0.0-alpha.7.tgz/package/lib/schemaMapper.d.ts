import { Column } from "@dashin-dev/dashin";
import { AtomoModelMeta } from "./types";
export declare function humanizeTitle(name: string): string;
export declare function mapAtomoTypeToColumnType(type: string): "string" | "numeric" | "boolean" | "datetime";
export interface SchemaMapperOptions {
    /** Optional custom title formatter */
    formatTitle?: (fieldName: string) => string;
    /** Fields that should always be hidden in the list view */
    alwaysHiddenFields?: string[];
    /** Override column definitions by field name */
    overrides?: Record<string, Partial<Column<any>>>;
    /** Enable automatic RelatedCard rendering for relation fields */
    autoRelatedCard?: boolean;
}
export declare function atomoFieldsToDashinColumns<RowData extends object = any>(modelMeta: AtomoModelMeta, options?: SchemaMapperOptions): Column<RowData>[];
