import { AtomoSchemaMeta } from "./types";
export interface AtomoClientOptions {
    baseUrl?: string;
    token?: string;
    fetchFn?: typeof fetch;
}
export declare function camelizeKeys(obj: any): any;
export declare function getAtomoBaseUrl(override?: string): string;
export declare function getAtomoToken(override?: string): Promise<string | null>;
export declare function fetchAtomoMetadata(options?: AtomoClientOptions): Promise<AtomoSchemaMeta>;
export declare function atomoGraphQLRequest<T = any>(query: string, variables?: Record<string, any>, options?: AtomoClientOptions): Promise<T>;
export declare function atomoListRecords<T = any>(model: string, params: {
    page?: number;
    limit?: number;
    where?: Record<string, any>;
    orderBy?: Record<string, string>;
}, options?: AtomoClientOptions): Promise<{
    data: T[];
    totalCount: number;
    page: number;
    limit: number;
}>;
export declare function atomoCreateRecord<T = any>(model: string, record: Record<string, any>, options?: AtomoClientOptions): Promise<T>;
export declare function atomoUpdateRecord<T = any>(model: string, id: string, record: Record<string, any>, options?: AtomoClientOptions): Promise<T>;
export declare function atomoGetRecord<T = any>(model: string, id: string, options?: AtomoClientOptions): Promise<T>;
export declare function atomoDeleteRecord(model: string, id: string, options?: AtomoClientOptions): Promise<void>;
