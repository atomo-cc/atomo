import React from "react";
import { AtomoModelMeta, AtomoSchemaMeta } from "../types";
import { Column, CollectionRegistry } from "@dashin-dev/dashin";
export interface AtomoContextValue {
    schema: AtomoSchemaMeta | null;
    registry: CollectionRegistry;
    loading: boolean;
    error: Error | null;
    refreshSchema: () => Promise<void>;
    baseUrl?: string;
}
export interface DynamicAtomoProviderProps {
    children: React.ReactNode;
    baseUrl?: string;
    initialSchema?: AtomoSchemaMeta;
}
export declare const DynamicAtomoProvider: React.FC<DynamicAtomoProviderProps>;
export declare function useAtomoSchema(): AtomoContextValue;
export declare function useAtomoModel<RowData extends object = any>(modelName: string): {
    modelMeta: AtomoModelMeta | null;
    columns: Column<RowData>[];
    loading: boolean;
    error: Error | null;
};
