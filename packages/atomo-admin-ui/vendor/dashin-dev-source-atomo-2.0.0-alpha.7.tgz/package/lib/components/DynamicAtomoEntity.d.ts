import React from "react";
export interface DynamicAtomoEntityProps {
    model: string;
    title?: string;
    searchField?: string;
    disableAdd?: boolean;
    baseUrl?: string;
}
export declare const DynamicAtomoEntity: React.FC<DynamicAtomoEntityProps>;
export default DynamicAtomoEntity;
