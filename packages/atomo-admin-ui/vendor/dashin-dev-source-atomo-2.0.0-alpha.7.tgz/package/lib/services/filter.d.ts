import { Filter, Query } from "@dashin-dev/dashin";
/** Map one Dashin table filter operator to an Atomo where operator. */
export declare function atomoOp(operator: string): string;
export declare function buildAtomoWhere(filters?: Filter<any>[], searchWords?: string, searchField?: string): Record<string, any>;
export declare function buildAtomoOrderBy(orderBy?: any, orderDirection?: string): Record<string, string> | undefined;
export declare function buildAtomoQueryParams<RowData extends object>(query: Query<RowData>, searchField?: string): {
    page: number;
    limit: number;
    where: Record<string, any>;
    orderBy?: Record<string, string>;
};
